<footer>
	<div class="infoBlock">
	</div>
	<nav class="navBlock">
		<ul class="navItemList">
			<li>***</li>
			<li>|</li>
			<li>***</li>
			<li>|</li>
			<li>***</li>
			<li>|</li>
			<li>***</li>
			<li>|</li>
			<li>***</li>
		</ul>
	</nav>
</footer>
<?php wp_footer(); ?><!--システム・プラグイン情報の出力-->
</body>
</html>
