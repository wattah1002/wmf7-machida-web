<!doctype html>
<html>
<head>
<meta charset="utf-8"> <!--エンコードの指定-->
<meta name="viewport" content="width=device-width, initial-scale=1.0 "><!--viewportの設定-->
<title>WMF7 Machida</title>
<link href="<?php echo get_stylesheet_uri(); ?>" rel="stylesheet" type="text/css">
<?php wp_head(); ?><!--システム・プラグイン情報の出力-->
</head>
<body>
<header>
</header>
