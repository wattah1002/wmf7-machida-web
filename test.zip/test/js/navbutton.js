jQuery(function() {
  jQuery("#navbutton").click(function() {
      jQuery("#header-nav-wrap").slideToggle();
  });
});
