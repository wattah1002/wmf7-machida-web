<aside id="sidebar" class="sidebar">
  <div class="sidebar-inner">
    <?php dynamic_sidebar( 'side-widget' ); ?>
  </div><!--end sidebar-inner-->
</aside>
