<?php get_header(); ?>
<div class="container">
  <div class="contents">

  </div><!--end contents-->
  <?php get_sidebar(); ?>
</div><!--end container-->
<?php get_footer(); ?>
